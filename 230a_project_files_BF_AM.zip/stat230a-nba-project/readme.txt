Authors: Brian Fernando and Anant Mashiana

All web scraping and data cleaning scripts for the generation of our dataset are in the folder data_scrape_and_clean

The final_dataset folder contains two identical datasets except one is from the 2022-23 NBA season and one is from the 2023-24 NBA season. We used the more recent one which is titled player_2024_final.csv

eda.R contains code for generating heatmaps which were used to check for correlated features

modeling.R contains code for OLS, WLS, and LASSO modeling

data_viz_and_assumptions.R loads the models as they were saved from modeling.R and all assumption checks are conducted in that file and all data visualizations are egenrated there

The rds objects and ints.csv are read into the latter R file

The report folder contains a pdf of our report (submitted on Gradescope as well) and the .tex file and images